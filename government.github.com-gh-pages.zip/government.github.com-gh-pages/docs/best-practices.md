---
redirect_to: http://government.github.io/best-practices/
permalink: /best-practices/index.html
---
